
    use: {
        loader: 'babel-loader';
        options: {
          
          presets: ['@babel/preset-env'];
        }
      }

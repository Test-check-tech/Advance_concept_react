import React from 'react'
import Columns from './Columns'
import AppContent from './test'
class App extends React.Component {
  render() {
    return (
      <>
        <h1>Content Builder</h1>
        <table>
        <tr>
          <Columns />

        </tr>
      </table>
      <AppContent />
      </>
        );
  }
}
export default App
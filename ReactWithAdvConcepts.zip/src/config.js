export const props = {
		api_url: "/api"
};
